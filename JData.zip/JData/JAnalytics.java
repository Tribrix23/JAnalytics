package JData;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class JAnalytics {
    public List<String> column = new ArrayList<>();
    public List<List<String>> row = new ArrayList<>();

    public JAnalytics() {}

    private JAnalytics deepCopy() {
        JAnalytics n = new JAnalytics();
        n.column = new ArrayList<>(this.column);
        n.row = new ArrayList<>();
        for (List<String> r : this.row) n.row.add(new ArrayList<>(r));
        return n;
    }

    public void readCSV(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            boolean isHeader = true;
            row = new ArrayList<>();
            column = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] data = line.split(",");
                if (isHeader) {
                    column = new ArrayList<>();
                    for (String colName : data) column.add(colName.trim());
                    isHeader = false;
                } else {
                    List<String> rowData = new ArrayList<>();
                    for (String value : data) rowData.add(value.trim());
                    row.add(rowData);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading CSV file: " + e.getMessage(), e);
        }
    }

    @Override
    public String toString() {
        if (column.isEmpty()) return "No data loaded.";
        int[] widths = new int[column.size()];
        for (int i = 0; i < column.size(); i++) {
            int max = column.get(i).length();
            for (List<String> r : row) {
                if (i < r.size() && r.get(i) != null && r.get(i).length() > max) {
                    max = r.get(i).length();
                }
            }
            widths[i] = max + 2;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < column.size(); i++) {
            sb.append(String.format("%-" + widths[i] + "s", column.get(i)));
            if (i < column.size() - 1) sb.append("| ");
        }
        sb.append("\n");
        for (int i = 0; i < column.size(); i++) {
            sb.append("-".repeat(widths[i]));
            if (i < column.size() - 1) sb.append("+-");
        }
        sb.append("\n");
        for (List<String> r : row) {
            for (int i = 0; i < column.size(); i++) {
                String val = (i < r.size() && r.get(i) != null) ? r.get(i) : "";
                sb.append(String.format("%-" + widths[i] + "s", val));
                if (i < column.size() - 1) sb.append("| ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public JAnalytics toCSV(String filename) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            bw.write(String.join(",", column));
            bw.newLine();
            for (List<String> r : row) {
                List<String> safe = new ArrayList<>();
                for (String v : r) safe.add(v == null ? "" : v);
                bw.write(String.join(",", safe));
                bw.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException("Error writing CSV file: " + e.getMessage(), e);
        }
        return this.deepCopy();
    }

    public JAnalytics readExcel(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            boolean isHeader = true;
            row = new ArrayList<>();
            column = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] data = line.split("\t|,");
                if (isHeader) {
                    for (String colName : data) column.add(colName.trim());
                    isHeader = false;
                } else {
                    List<String> rowData = new ArrayList<>();
                    for (String value : data) rowData.add(value.trim());
                    row.add(rowData);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading Excel-like file: " + e.getMessage(), e);
        }
        return this.deepCopy();
    }

    public JAnalytics toExcel(String filename) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            bw.write(String.join("\t", column));
            bw.newLine();
            for (List<String> r : row) {
                List<String> safe = new ArrayList<>();
                for (String v : r) safe.add(v == null ? "" : v);
                bw.write(String.join("\t", safe));
                bw.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException("Error writing Excel-like file: " + e.getMessage(), e);
        }
        return this.deepCopy();
    }

    private List<Map<String, String>> parseJsonArray(String json) {
        List<Map<String, String>> list = new ArrayList<>();
        int i = 0;
        int n = json.length();
        while (i < n && Character.isWhitespace(json.charAt(i))) i++;
        if (i >= n || json.charAt(i) != '[') return list;
        i++;
        while (i < n) {
            while (i < n && Character.isWhitespace(json.charAt(i))) i++;
            if (i < n && json.charAt(i) == ']') break;
            if (i < n && json.charAt(i) == '{') {
                int start = i;
                int brace = 0;
                boolean inString = false;
                while (i < n) {
                    char c = json.charAt(i);
                    if (c == '"' && (i == 0 || json.charAt(i - 1) != '\\')) inString = !inString;
                    if (!inString) {
                        if (c == '{') brace++;
                        else if (c == '}') {
                            brace--;
                            if (brace == 0) {
                                i++;
                                break;
                            }
                        }
                    }
                    i++;
                }
                String obj = json.substring(start, i);
                Map<String, String> map = new LinkedHashMap<>();
                int j = 0;
                int m = obj.length();
                while (j < m && obj.charAt(j) != '{') j++;
                j++;
                while (j < m) {
                    while (j < m && Character.isWhitespace(obj.charAt(j))) j++;
                    if (j < m && obj.charAt(j) == '}') break;
                    if (j >= m) break;
                    if (obj.charAt(j) == '"') {
                        int keyStart = j + 1;
                        j++;
                        StringBuilder keySb = new StringBuilder();
                        while (j < m) {
                            char c = obj.charAt(j);
                            if (c == '"' && obj.charAt(j - 1) != '\\') { j++; break; }
                            keySb.append(c);
                            j++;
                        }
                        while (j < m && Character.isWhitespace(obj.charAt(j))) j++;
                        if (j < m && obj.charAt(j) == ':') j++;
                        while (j < m && Character.isWhitespace(obj.charAt(j))) j++;
                        String value = "";
                        if (j < m && obj.charAt(j) == '"') {
                            j++;
                            StringBuilder valSb = new StringBuilder();
                            while (j < m) {
                                char c = obj.charAt(j);
                                if (c == '"' && obj.charAt(j - 1) != '\\') { j++; break; }
                                valSb.append(c);
                                j++;
                            }
                            value = valSb.toString();
                        } else {
                            StringBuilder valSb = new StringBuilder();
                            while (j < m) {
                                char c = obj.charAt(j);
                                if (c == ',' || c == '}') break;
                                valSb.append(c);
                                j++;
                            }
                            value = valSb.toString().trim();
                        }
                        map.put(keySb.toString(), value);
                        while (j < m && obj.charAt(j) != ',' && obj.charAt(j) != '}') j++;
                        if (j < m && obj.charAt(j) == ',') j++;
                    } else {
                        j++;
                    }
                }
                list.add(map);
                while (i < n && Character.isWhitespace(json.charAt(i))) i++;
                if (i < n && json.charAt(i) == ',') i++;
            } else {
                i++;
            }
        }
        return list;
    }

    public JAnalytics readJSON(String filename) {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        } catch (IOException e) {
            throw new RuntimeException("Error reading JSON file: " + e.getMessage(), e);
        }
        List<Map<String, String>> objs = parseJsonArray(sb.toString());
        column = new ArrayList<>();
        row = new ArrayList<>();
        if (objs.isEmpty()) return this.deepCopy();
        Map<String, String> first = objs.get(0);
        for (String k : first.keySet()) column.add(k);
        for (Map<String, String> m : objs) {
            List<String> r = new ArrayList<>();
            for (String c : column) r.add(m.getOrDefault(c, ""));
            row.add(r);
        }
        return this.deepCopy();
    }

    public JAnalytics toJSON(String filename) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            bw.write("[\n");
            for (int i = 0; i < row.size(); i++) {
                List<String> r = row.get(i);
                bw.write("  {");
                for (int j = 0; j < column.size(); j++) {
                    String k = column.get(j);
                    String v = j < r.size() && r.get(j) != null ? r.get(j) : "";
                    bw.write("\"" + k.replace("\"", "\\\"") + "\": \"" + v.replace("\"", "\\\"") + "\"");
                    if (j < column.size() - 1) bw.write(", ");
                }
                bw.write("}");
                if (i < row.size() - 1) bw.write(",");
                bw.write("\n");
            }
            bw.write("]");
        } catch (IOException e) {
            throw new RuntimeException("Error writing JSON file: " + e.getMessage(), e);
        }
        return this.deepCopy();
    }

    public JAnalytics readSQL(String query, Connection connection) {
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            ResultSetMetaData meta = rs.getMetaData();
            int colCount = meta.getColumnCount();
            column = new ArrayList<>();
            row = new ArrayList<>();
            for (int i = 1; i <= colCount; i++) column.add(meta.getColumnName(i));
            while (rs.next()) {
                List<String> r = new ArrayList<>();
                for (int i = 1; i <= colCount; i++) r.add(rs.getString(i));
                row.add(r);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error reading SQL data: " + e.getMessage(), e);
        }
        return this.deepCopy();
    }

    public JAnalytics readHTML(String filename) {
        StringBuilder html = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) html.append(line);
        } catch (IOException e) {
            throw new RuntimeException("Error reading HTML file: " + e.getMessage(), e);
        }
        String content = html.toString().replaceAll("\\s+", " ").replaceAll("(?i)</tr>", "</tr>\n");
        column = new ArrayList<>();
        row = new ArrayList<>();
        int headerStart = content.toLowerCase().indexOf("<th");
        if (headerStart != -1) {
            String[] headers = content.split("(?i)</th>");
            for (String h : headers) {
                int start = h.toLowerCase().indexOf(">");
                if (start != -1) {
                    String name = h.substring(start + 1).trim();
                    if (!name.isEmpty() && !name.contains("<")) column.add(name);
                }
            }
        }
        String[] rowsArr = content.split("(?i)</tr>");
        for (String r : rowsArr) {
            if (!r.toLowerCase().contains("<td")) continue;
            List<String> rowData = new ArrayList<>();
            String[] cells = r.split("(?i)</td>");
            for (String c : cells) {
                int start = c.toLowerCase().indexOf(">");
                if (start != -1) {
                    String val = c.substring(start + 1).trim();
                    if (!val.isEmpty() && !val.contains("<")) rowData.add(val);
                }
            }
            if (!rowData.isEmpty()) row.add(rowData);
        }
        return this.deepCopy();
    }

    public JAnalytics readParquet(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            boolean isHeader = true;
            column = new ArrayList<>();
            row = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] data = line.split("\\|");
                if (isHeader) {
                    for (String colName : data) column.add(colName.trim());
                    isHeader = false;
                } else {
                    List<String> rowData = new ArrayList<>();
                    for (String value : data) rowData.add(value.trim());
                    row.add(rowData);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading Parquet-like file: " + e.getMessage(), e);
        }
        return this.deepCopy();
    }

    public JAnalytics readFeather(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            boolean isHeader = true;
            column = new ArrayList<>();
            row = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] data = line.split("\\|");
                if (isHeader) {
                    for (String colName : data) column.add(colName.trim());
                    isHeader = false;
                } else {
                    List<String> rowData = new ArrayList<>();
                    for (String value : data) rowData.add(value.trim());
                    row.add(rowData);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading Feather-like file: " + e.getMessage(), e);
        }
        return this.deepCopy();
    }

    public JAnalytics filter(String expr) {
        String[] parts;
        String colName;
        String op;
        String val;
        expr = expr.trim();
        if (expr.contains("==")) parts = expr.split("==", 2);
        else if (expr.contains("!=")) parts = expr.split("!=", 2);
        else if (expr.contains(">=")) parts = expr.split(">=", 2);
        else if (expr.contains("<=")) parts = expr.split("<=", 2);
        else if (expr.contains(">")) parts = expr.split(">", 2);
        else if (expr.contains("<")) parts = expr.split("<", 2);
        else if (expr.contains(" contains ")) parts = expr.split(" contains ", 2);
        else if (expr.contains(" startswith ")) parts = expr.split(" startswith ", 2);
        else if (expr.contains(" endswith ")) parts = expr.split(" endswith ", 2);
        else return this.deepCopy();
        if (parts.length < 2) return this.deepCopy();
        colName = parts[0].trim();
        val = parts[1].trim();
        if (expr.contains("==")) op = "==";
        else if (expr.contains("!=")) op = "!=";
        else if (expr.contains(">=")) op = ">=";
        else if (expr.contains("<=")) op = "<=";
        else if (expr.contains(">")) op = ">";
        else if (expr.contains("<")) op = "<";
        else if (expr.contains(" contains ")) op = "contains";
        else if (expr.contains(" startswith ")) op = "startswith";
        else if (expr.contains(" endswith ")) op = "endswith";
        else op = "==";
        int idx = column.indexOf(colName);
        if (idx == -1) return this.deepCopy();
        List<List<String>> filtered = new ArrayList<>();
        for (List<String> r : row) {
            String cell = (idx < r.size() && r.get(idx) != null) ? r.get(idx) : "";
            boolean match = false;
            try {
                double cellNum = Double.parseDouble(cell);
                double valNum = Double.parseDouble(val);
                switch (op) {
                    case ">": match = cellNum > valNum; break;
                    case "<": match = cellNum < valNum; break;
                    case ">=": match = cellNum >= valNum; break;
                    case "<=": match = cellNum <= valNum; break;
                    case "==": match = cellNum == valNum; break;
                    case "!=": match = cellNum != valNum; break;
                }
            } catch (NumberFormatException e) {
                switch (op) {
                    case "==": match = cell.equals(val); break;
                    case "!=": match = !cell.equals(val); break;
                    case "contains": match = cell.contains(val); break;
                    case "startswith": match = cell.startsWith(val); break;
                    case "endswith": match = cell.endsWith(val); break;
                }
            }
            if (match) filtered.add(new ArrayList<>(r));
        }
        JAnalytics out = this.deepCopy();
        this.row = filtered;
        out.row = new ArrayList<>();
        for (List<String> r : filtered) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics filter(String columnName, java.util.function.Predicate<String> condition) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        List<List<String>> newRows = new ArrayList<>();
        for (List<String> r : row) {
            String val = (idx < r.size()) ? r.get(idx) : "";
            if (condition.test(val)) newRows.add(new ArrayList<>(r));
        }
        JAnalytics out = this.deepCopy();
        out.row = newRows;
        return out;
    }

    public JAnalytics groupby(String columnName) {
        JAnalytics grouped = new JAnalytics();
        grouped.column = new ArrayList<>(this.column);
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();

        Map<String, List<List<String>>> groups = new LinkedHashMap<>();
        for (List<String> r : row) {
            String key = (idx < r.size()) ? r.get(idx) : "";
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(r);
        }

        grouped.row = new ArrayList<>(groups.values().stream()
                .map(list -> list.get(0))
                .collect(Collectors.toList()));
        grouped.column = new ArrayList<>(this.column);
        grouped.row = new ArrayList<>(groups.keySet().stream()
                .map(k -> Collections.singletonList(k))
                .collect(Collectors.toList()));

        grouped._groups = groups; // optional for chaining
        return grouped;
    }

    private Map<String, List<List<String>>> _groups;

    public JAnalytics agg(String func) {
        if (_groups == null) return this.deepCopy();
        List<String> newCols = new ArrayList<>(column);
        List<List<String>> newRows = new ArrayList<>();
        for (Map.Entry<String, List<List<String>>> e : _groups.entrySet()) {
            List<String> r = new ArrayList<>();
            r.add(e.getKey());
            List<List<String>> group = e.getValue();
            for (int i = 1; i < column.size(); i++) {
                try {
                    int finalI = i;
                    double avg = group.stream()
                            .mapToDouble(row -> Double.parseDouble(row.get(finalI)))
                            .average().orElse(0);
                    r.add(String.format("%.2f", avg));
                } catch (Exception ex) {
                    r.add("");
                }
            }
            newRows.add(r);
        }
        JAnalytics out = new JAnalytics();
        out.column = newCols;
        out.row = newRows;
        return out;
    }



    public JAnalytics isna() {
        List<List<String>> newRows = new ArrayList<>();
        for (List<String> r : row) {
            List<String> nr = new ArrayList<>();
            for (String v : r) {
                if (v == null || v.trim().isEmpty() || v.equalsIgnoreCase("NaN")) nr.add("true");
                else nr.add("false");
            }
            newRows.add(nr);
        }
        JAnalytics out = this.deepCopy();
        this.row = newRows;
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics fillna(String value) {
        List<List<String>> newRows = new ArrayList<>();
        for (List<String> r : row) {
            List<String> nr = new ArrayList<>();
            for (String v : r) {
                if (v == null || v.trim().isEmpty() || v.equalsIgnoreCase("NaN")) nr.add(value);
                else nr.add(v);
            }
            newRows.add(nr);
        }
        JAnalytics out = this.deepCopy();
        this.row = newRows;
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics dropna() {
        List<List<String>> newRows = row.stream()
                .filter(r -> r.stream().noneMatch(v -> v == null || v.trim().isEmpty() || v.equalsIgnoreCase("NaN")))
                .map(r -> new ArrayList<>(r))
                .collect(Collectors.toList());
        JAnalytics out = this.deepCopy();
        this.row = newRows;
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics strLower(String columnName) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        List<List<String>> newRows = new ArrayList<>();
        for (List<String> r : row) {
            List<String> nr = new ArrayList<>(r);
            if (idx < nr.size() && nr.get(idx) != null) nr.set(idx, nr.get(idx).toLowerCase());
            newRows.add(nr);
        }
        JAnalytics out = this.deepCopy();
        this.row = newRows;
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics strReplace(String columnName, String target, String replacement) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        List<List<String>> newRows = new ArrayList<>();
        for (List<String> r : row) {
            List<String> nr = new ArrayList<>(r);
            if (idx < nr.size() && nr.get(idx) != null) nr.set(idx, nr.get(idx).replace(target, replacement));
            newRows.add(nr);
        }
        JAnalytics out = this.deepCopy();
        this.row = newRows;
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics astype(String columnName, String type) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        List<List<String>> newRows = new ArrayList<>();
        for (List<String> r : row) {
            List<String> nr = new ArrayList<>(r);
            String val = idx < nr.size() && nr.get(idx) != null ? nr.get(idx) : "";
            try {
                switch (type.toLowerCase()) {
                    case "int": nr.set(idx, String.valueOf(Integer.parseInt(val))); break;
                    case "double": nr.set(idx, String.valueOf(Double.parseDouble(val))); break;
                    case "boolean": nr.set(idx, String.valueOf(Boolean.parseBoolean(val))); break;
                    case "string": nr.set(idx, val); break;
                    default: nr.set(idx, val);
                }
            } catch (Exception e) {
                nr.set(idx, "NaN");
            }
            newRows.add(nr);
        }
        JAnalytics out = this.deepCopy();
        this.row = newRows;
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics dropDuplicates() {
        Set<String> seen = new HashSet<>();
        List<List<String>> unique = new ArrayList<>();
        for (List<String> r : row) {
            String key = String.join("|", r);
            if (!seen.contains(key)) {
                seen.add(key);
                unique.add(new ArrayList<>(r));
            }
        }
        JAnalytics out = this.deepCopy();
        this.row = unique;
        out.row = new ArrayList<>();
        for (List<String> r : unique) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics apply(Function<List<String>, List<String>> func) {
        List<List<String>> newRows = new ArrayList<>();
        for (List<String> r : row) newRows.add(func.apply(new ArrayList<>(r)));
        JAnalytics out = this.deepCopy();
        this.row = newRows;
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics map(String columnName, Function<String, String> func) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        List<List<String>> newRows = new ArrayList<>();
        for (List<String> r : row) {
            List<String> nr = new ArrayList<>(r);
            if (idx < nr.size()) nr.set(idx, func.apply(nr.get(idx)));
            newRows.add(nr);
        }
        JAnalytics out = this.deepCopy();
        this.row = newRows;
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics applymap(Function<String, String> func) {
        List<List<String>> newRows = new ArrayList<>();
        for (List<String> r : row) {
            List<String> nr = new ArrayList<>();
            for (String v : r) nr.add(func.apply(v));
            newRows.add(nr);
        }
        JAnalytics out = this.deepCopy();
        this.row = newRows;
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics groupBy(String columnName) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        Map<String, List<List<String>>> grouped = new LinkedHashMap<>();
        for (List<String> r : row) {
            String key = (idx < r.size() && r.get(idx) != null) ? r.get(idx) : "";
            grouped.computeIfAbsent(key, k -> new ArrayList<>()).add(new ArrayList<>(r));
        }
        List<String> newCols = new ArrayList<>();
        newCols.add(columnName);
        newCols.add("Group Size");
        List<List<String>> newRows = new ArrayList<>();
        for (Map.Entry<String, List<List<String>>> entry : grouped.entrySet())
            newRows.add(new ArrayList<>(List.of(entry.getKey(), String.valueOf(entry.getValue().size()))));
        JAnalytics out = this.deepCopy();
        this.column = newCols;
        this.row = newRows;
        out.column = new ArrayList<>(newCols);
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics sum(String columnName) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        double total = 0.0;
        for (List<String> r : row) {
            try { total += Double.parseDouble(r.get(idx)); } catch (Exception ignored) {}
        }
        List<String> newCols = new ArrayList<>(List.of("Sum of " + columnName));
        List<List<String>> newRows = new ArrayList<>(List.of(new ArrayList<>(List.of(String.valueOf(total)))));
        JAnalytics out = this.deepCopy();
        this.column = newCols;
        this.row = newRows;
        out.column = new ArrayList<>(newCols);
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics mean(String columnName) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        double total = 0.0;
        int count = 0;
        for (List<String> r : row) {
            try { total += Double.parseDouble(r.get(idx)); count++; } catch (Exception ignored) {}
        }
        double avg = count > 0 ? total / count : 0;
        List<String> newCols = new ArrayList<>(List.of("Mean of " + columnName));
        List<List<String>> newRows = new ArrayList<>(List.of(new ArrayList<>(List.of(String.format("%.2f", avg)))));
        JAnalytics out = this.deepCopy();
        this.column = newCols;
        this.row = newRows;
        out.column = new ArrayList<>(newCols);
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics count(String columnName) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        int count = 0;
        for (List<String> r : row) if (idx < r.size() && r.get(idx) != null && !r.get(idx).trim().isEmpty()) count++;
        List<String> newCols = new ArrayList<>(List.of("Count of " + columnName));
        List<List<String>> newRows = new ArrayList<>(List.of(new ArrayList<>(List.of(String.valueOf(count)))));
        JAnalytics out = this.deepCopy();
        this.column = newCols;
        this.row = newRows;
        out.column = new ArrayList<>(newCols);
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics agg(String columnName, String operation) {
        switch (operation.toLowerCase()) {
            case "sum": return sum(columnName);
            case "mean": return mean(columnName);
            case "count": return count(columnName);
            default: return this.deepCopy();
        }
    }

    public JAnalytics pivotTable(String indexCol, String columnsCol, String valuesCol, String aggFunc) {
        int idxIndex = column.indexOf(indexCol);
        int idxColumns = column.indexOf(columnsCol);
        int idxValues = column.indexOf(valuesCol);
        if (idxIndex == -1 || idxColumns == -1 || idxValues == -1) return this.deepCopy();
        Map<String, Map<String, List<Double>>> table = new LinkedHashMap<>();
        for (List<String> r : row) {
            String indexVal = idxIndex < r.size() && r.get(idxIndex) != null ? r.get(idxIndex) : "";
            String colVal = idxColumns < r.size() && r.get(idxColumns) != null ? r.get(idxColumns) : "";
            double val = 0.0;
            try { val = Double.parseDouble(idxValues < r.size() && r.get(idxValues) != null ? r.get(idxValues) : "0"); } catch (Exception ignored) {}
            table.computeIfAbsent(indexVal, k -> new LinkedHashMap<>()).computeIfAbsent(colVal, k -> new ArrayList<>()).add(val);
        }
        Set<String> allColumns = new LinkedHashSet<>();
        for (Map<String, List<Double>> map : table.values()) allColumns.addAll(map.keySet());
        List<String> newCols = new ArrayList<>();
        newCols.add(indexCol);
        newCols.addAll(allColumns);
        List<List<String>> newRows = new ArrayList<>();
        for (Map.Entry<String, Map<String, List<Double>>> entry : table.entrySet()) {
            List<String> newRow = new ArrayList<>();
            newRow.add(entry.getKey());
            for (String c : allColumns) {
                List<Double> vals = entry.getValue().get(c);
                double result = 0.0;
                if (vals != null && !vals.isEmpty()) {
                    switch (aggFunc.toLowerCase()) {
                        case "sum": result = vals.stream().mapToDouble(Double::doubleValue).sum(); break;
                        case "mean": result = vals.stream().mapToDouble(Double::doubleValue).average().orElse(0.0); break;
                        case "count": result = vals.size(); break;
                    }
                }
                newRow.add(String.format("%.2f", result));
            }
            newRows.add(newRow);
        }
        JAnalytics out = this.deepCopy();
        this.column = newCols;
        this.row = newRows;
        out.column = new ArrayList<>(newCols);
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics to_datetime(String columnName, String format) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        List<List<String>> newRows = new ArrayList<>();
        for (List<String> r : row) {
            List<String> nr = new ArrayList<>(r);
            try {
                String raw = idx < nr.size() && nr.get(idx) != null ? nr.get(idx) : "";
                LocalDate date = LocalDate.parse(raw, formatter);
                nr.set(idx, date.toString());
            } catch (Exception ignored) {}
            newRows.add(nr);
        }
        JAnalytics out = this.deepCopy();
        this.row = newRows;
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics resample(String columnName, String freq, String aggColumn, String aggFunc) {
        int idxDate = column.indexOf(columnName);
        int idxVal = column.indexOf(aggColumn);
        if (idxDate == -1 || idxVal == -1) return this.deepCopy();
        Map<String, List<Double>> grouped = new LinkedHashMap<>();
        for (List<String> r : row) {
            try {
                LocalDate date = LocalDate.parse(r.get(idxDate));
                String key;
                if (freq.equalsIgnoreCase("M")) key = date.getYear() + "-" + String.format("%02d", date.getMonthValue());
                else if (freq.equalsIgnoreCase("Y")) key = String.valueOf(date.getYear());
                else key = date.toString();
                double val = Double.parseDouble(r.get(idxVal));
                grouped.computeIfAbsent(key, k -> new ArrayList<>()).add(val);
            } catch (Exception ignored) {}
        }
        List<String> newCols = new ArrayList<>(List.of("Period", aggFunc + "(" + aggColumn + ")"));
        List<List<String>> newRows = new ArrayList<>();
        for (Map.Entry<String, List<Double>> e : grouped.entrySet()) {
            List<Double> vals = e.getValue();
            double result = 0;
            switch (aggFunc.toLowerCase()) {
                case "sum": result = vals.stream().mapToDouble(Double::doubleValue).sum(); break;
                case "mean": result = vals.stream().mapToDouble(Double::doubleValue).average().orElse(0.0); break;
                case "count": result = vals.size(); break;
            }
            newRows.add(new ArrayList<>(List.of(e.getKey(), String.format("%.2f", result))));
        }
        JAnalytics out = this.deepCopy();
        this.column = newCols;
        this.row = newRows;
        out.column = new ArrayList<>(newCols);
        out.row = new ArrayList<>();
        for (List<String> r : newRows) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics shift(int periods) {
        if (row.isEmpty() || periods == 0) return this.deepCopy();
        int size = row.size();
        List<List<String>> shifted = new ArrayList<>(Collections.nCopies(size, null));
        for (int i = 0; i < size; i++) {
            int newIndex = i + periods;
            if (newIndex >= 0 && newIndex < size) shifted.set(newIndex, new ArrayList<>(row.get(i)));
        }
        for (int i = 0; i < size; i++) {
            if (shifted.get(i) == null) {
                List<String> emptyRow = new ArrayList<>();
                for (int j = 0; j < column.size(); j++) emptyRow.add("");
                shifted.set(i, emptyRow);
            }
        }
        JAnalytics out = this.deepCopy();
        this.row = shifted;
        out.row = new ArrayList<>();
        for (List<String> r : shifted) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics timeSlice(String columnName, String start, String end) {
        int idx = column.indexOf(columnName);
        if (idx == -1) return this.deepCopy();
        LocalDate startDate = LocalDate.parse(start);
        LocalDate endDate = LocalDate.parse(end);
        List<List<String>> filtered = new ArrayList<>();
        for (List<String> r : row) {
            try {
                LocalDate date = LocalDate.parse(r.get(idx));
                if (!date.isBefore(startDate) && !date.isAfter(endDate)) filtered.add(new ArrayList<>(r));
            } catch (Exception ignored) {}
        }
        JAnalytics out = this.deepCopy();
        this.row = filtered;
        out.row = new ArrayList<>();
        for (List<String> r : filtered) out.row.add(new ArrayList<>(r));
        return out;
    }

    public JAnalytics merge(JAnalytics other) {
        JAnalytics result = new JAnalytics();
        result.column.addAll(this.column);
        for (String col : other.column) {
            if (!result.column.contains(col)) result.column.add(col);
        }
        for (List<String> r1 : this.row) {
            for (List<String> r2 : other.row) {
                List<String> merged = new ArrayList<>();
                merged.addAll(r1);
                merged.addAll(r2);
                result.row.add(merged);
            }
        }
        this.column = result.column;
        this.row = result.row;
        return result;
    }

    public JAnalytics join(JAnalytics other) {
        JAnalytics result = new JAnalytics();
        result.column.addAll(this.column);
        for (String col : other.column) {
            if (!result.column.contains(col)) result.column.add(col);
        }
        int size = Math.max(this.row.size(), other.row.size());
        for (int i = 0; i < size; i++) {
            List<String> joined = new ArrayList<>();
            if (i < this.row.size()) joined.addAll(this.row.get(i));
            else joined.addAll(Collections.nCopies(this.column.size(), ""));
            if (i < other.row.size()) joined.addAll(other.row.get(i));
            else joined.addAll(Collections.nCopies(other.column.size(), ""));
            result.row.add(joined);
        }
        this.column = result.column;
        this.row = result.row;
        return result;
    }

    public JAnalytics concat(JAnalytics other) {
        JAnalytics result = new JAnalytics();
        result.column.addAll(this.column);
        result.row.addAll(this.row);
        result.row.addAll(other.row);
        this.row = result.row;
        return result;
    }

    public JAnalytics melt(String idVar, String valueVar) {
        JAnalytics result = new JAnalytics();
        result.column = Arrays.asList(idVar, "variable", valueVar);
        for (List<String> r : this.row) {
            for (int i = 1; i < column.size(); i++) {
                List<String> newRow = new ArrayList<>();
                newRow.add(r.get(0));
                newRow.add(column.get(i));
                newRow.add(r.get(i));
                result.row.add(newRow);
            }
        }
        this.column = result.column;
        this.row = result.row;
        return result;
    }

    public JAnalytics pivot(String index, String columns, String values) {
        JAnalytics result = new JAnalytics();
        int idxIndex = this.column.indexOf(index);
        int idxCols = this.column.indexOf(columns);
        int idxVals = this.column.indexOf(values);
        Set<String> uniqueCols = new LinkedHashSet<>();
        for (List<String> r : row) uniqueCols.add(r.get(idxCols));
        result.column.add(index);
        result.column.addAll(uniqueCols);
        Map<String, Map<String, String>> pivotData = new LinkedHashMap<>();
        for (List<String> r : row) {
            String key = r.get(idxIndex);
            String colKey = r.get(idxCols);
            String val = r.get(idxVals);
            pivotData.putIfAbsent(key, new LinkedHashMap<>());
            pivotData.get(key).put(colKey, val);
        }
        for (String key : pivotData.keySet()) {
            List<String> newRow = new ArrayList<>();
            newRow.add(key);
            Map<String, String> map = pivotData.get(key);
            for (String col : uniqueCols) newRow.add(map.getOrDefault(col, ""));
            result.row.add(newRow);
        }
        this.column = result.column;
        this.row = result.row;
        return result;
    }

    public JAnalytics stack() {
        JAnalytics result = new JAnalytics();
        result.column = Arrays.asList("index", "variable", "value");
        for (int i = 0; i < row.size(); i++) {
            List<String> r = row.get(i);
            for (int j = 0; j < column.size(); j++) {
                List<String> newRow = new ArrayList<>();
                newRow.add(String.valueOf(i));
                newRow.add(column.get(j));
                newRow.add(r.get(j));
                result.row.add(newRow);
            }
        }
        this.column = result.column;
        this.row = result.row;
        return result;
    }

    public JAnalytics unstack() {
        JAnalytics result = new JAnalytics();
        Set<String> variables = new LinkedHashSet<>();
        Map<String, Map<String, String>> temp = new LinkedHashMap<>();
        for (List<String> r : row) {
            String index = r.get(0);
            String var = r.get(1);
            String val = r.get(2);
            variables.add(var);
            temp.putIfAbsent(index, new LinkedHashMap<>());
            temp.get(index).put(var, val);
        }
        result.column.add("index");
        result.column.addAll(variables);
        for (String idx : temp.keySet()) {
            List<String> newRow = new ArrayList<>();
            newRow.add(idx);
            Map<String, String> map = temp.get(idx);
            for (String v : variables) newRow.add(map.getOrDefault(v, ""));
            result.row.add(newRow);
        }
        this.column = result.column;
        this.row = result.row;
        return result;
    }

    public JAnalytics loc(String columnName, String value) {
        JAnalytics result = new JAnalytics();
        result.column.addAll(this.column);
        int colIndex = this.column.indexOf(columnName);
        if (colIndex == -1) return this;
        for (List<String> r : this.row) {
            if (r.get(colIndex).equals(value)) result.row.add(new ArrayList<>(r));
        }
        this.row = result.row;
        return result;
    }

    public JAnalytics iloc(int start, int end) {
        JAnalytics result = new JAnalytics();
        result.column.addAll(this.column);
        for (int i = start; i < Math.min(end, this.row.size()); i++) {
            result.row.add(new ArrayList<>(this.row.get(i)));
        }
        this.row = result.row;
        return result;
    }

    public void to_datetime(String column) {
        to_datetime(column, "yyyy-MM-dd"); // calls the 2-arg method
    }


    public JAnalytics boolIndex(String columnName, String operator, double threshold) {
        JAnalytics result = new JAnalytics();
        result.column.addAll(this.column);
        int colIndex = this.column.indexOf(columnName);
        if (colIndex == -1) return this;
        for (List<String> r : this.row) {
            try {
                double val = Double.parseDouble(r.get(colIndex));
                boolean condition = switch (operator) {
                    case ">" -> val > threshold;
                    case "<" -> val < threshold;
                    case ">=" -> val >= threshold;
                    case "<=" -> val <= threshold;
                    case "==" -> val == threshold;
                    case "!=" -> val != threshold;
                    default -> false;
                };
                if (condition) result.row.add(new ArrayList<>(r));
            } catch (Exception ignored) {}
        }
        this.row = result.row;
        return result;
    }

    public JAnalytics multiIndex(String[] levels) {
        JAnalytics result = new JAnalytics();
        result.column.addAll(Arrays.asList(levels));
        for (List<String> r : this.row) {
            List<String> newRow = new ArrayList<>();
            for (String level : levels) {
                int idx = this.column.indexOf(level);
                newRow.add(idx >= 0 && idx < r.size() ? r.get(idx) : "");
            }
            result.row.add(newRow);
        }
        this.column = result.column;
        this.row = result.row;
        return result;
    }

    public PlotBuilder plot(String xColumn, String yColumn) {
        return new PlotBuilder(xColumn, yColumn);
    }

    public class PlotBuilder {
        private final int xIdx;
        private final int yIdx;
        private String title = "";
        private String xLabel;
        private String yLabel;
        private Color pointColor = Color.RED;
        private Color lineColor = Color.GREEN;
        private boolean drawLine = false;
        private boolean showMean = false;
        private boolean logScaleY = false;
        private int width = 900;
        private int height = 600;
        private final List<Double> xs = new ArrayList<>();
        private final List<Double> ys = new ArrayList<>();

        public PlotBuilder(String xColumn, String yColumn) {
            this.xIdx = column.indexOf(xColumn);
            this.yIdx = column.indexOf(yColumn);
            this.xLabel = xColumn;
            this.yLabel = yColumn;
            if (xIdx == -1 || yIdx == -1) throw new IllegalArgumentException("Column not found");
            for (List<String> r : row) {
                String sx = xIdx < r.size() ? r.get(xIdx) : "";
                String sy = yIdx < r.size() ? r.get(yIdx) : "";
                try {
                    xs.add(Double.parseDouble(sx));
                    ys.add(Double.parseDouble(sy));
                } catch (Exception e) { /* skip non-numeric */ }
            }
        }

        // --- Customization methods ---
        public PlotBuilder title(String t) { this.title = t; return this; }
        public PlotBuilder xlabel(String l) { this.xLabel = l; return this; }
        public PlotBuilder ylabel(String l) { this.yLabel = l; return this; }
        public PlotBuilder color(String colorName) { this.pointColor = parseColor(colorName, pointColor); return this; }
        public PlotBuilder lineColor(String colorName) { this.lineColor = parseColor(colorName, lineColor); return this; }
        public PlotBuilder line(boolean draw) { this.drawLine = draw; return this; }
        public PlotBuilder line(boolean draw, String colorName) { this.drawLine = draw; this.lineColor = parseColor(colorName, Color.GREEN); return this; }
        public PlotBuilder mean(boolean show) { this.showMean = show; return this; }
        public PlotBuilder size(int w, int h) { this.width = w; this.height = h; return this; }
        public PlotBuilder logY(boolean v) { this.logScaleY = v; return this; }

        // --- Plot types ---
        public PlotBuilder scatter() { renderScatter(); return this; }
        public PlotBuilder linePlot() { renderScatter(); return this; }
        public PlotBuilder bar() { renderBar(); return this; }
        public PlotBuilder hist() { renderHist(); return this; }
        public PlotBuilder pie() { renderPie(); return this; }
        public PlotBuilder show() { renderScatter(); return this; }

        private Color parseColor(String s, Color fallback) {
            if (s == null) return fallback;
            s = s.trim().toLowerCase();
            switch (s) {
                case "red": return Color.RED;
                case "blue": return Color.BLUE;
                case "green": return Color.GREEN;
                case "black": return Color.BLACK;
                case "gray": case "grey": return Color.GRAY;
                case "orange": return Color.ORANGE;
                case "pink": return Color.PINK;
                case "magenta": return Color.MAGENTA;
                case "yellow": return Color.YELLOW;
                case "cyan": return Color.CYAN;
                default:
                    try { return s.startsWith("#") ? Color.decode(s) : fallback; }
                    catch (Exception e) { return fallback; }
            }
        }

        // --- Scatter / Line rendering ---
        private void renderScatter() {
            SwingUtilities.invokeLater(() -> {
                JFrame frame = new JFrame(title.isEmpty() ? yLabel + " vs " + xLabel : title);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(width, height + 150);

                JPanel chart = new JPanel() {
                    protected void paintComponent(Graphics g0) {
                        super.paintComponent(g0);
                        Graphics2D g = (Graphics2D) g0;
                        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                        int marginLeft = 80, marginRight = 40, marginTop = 50, marginBottom = 90;
                        int w = getWidth(), h = getHeight();
                        int plotW = w - marginLeft - marginRight;
                        int plotH = h - marginTop - marginBottom;

                        g.setColor(Color.WHITE);
                        g.fillRect(0, 0, w, h);
                        g.setColor(Color.LIGHT_GRAY);
                        g.fillRect(marginLeft, marginTop, plotW, plotH);

                        double minX = xs.stream().mapToDouble(d -> d).min().orElse(0);
                        double maxX = xs.stream().mapToDouble(d -> d).max().orElse(1);
                        double minY = ys.stream().mapToDouble(d -> d).min().orElse(0);
                        double maxY = ys.stream().mapToDouble(d -> d).max().orElse(1);
                        if (minX == maxX) { minX -= 1; maxX += 1; }
                        if (minY == maxY) { minY -= 1; maxY += 1; }

                        // Draw axes
                        g.setColor(Color.BLACK);
                        g.setStroke(new BasicStroke(2));
                        g.drawRect(marginLeft, marginTop, plotW, plotH);

                        // X-axis ticks
                        g.setFont(new Font("SansSerif", Font.PLAIN, 12));
                        FontMetrics fm = g.getFontMetrics();
                        Set<Double> xVals = new TreeSet<>(xs);
                        for (double v : xVals) {
                            int x = marginLeft + (int)((v - minX)/(maxX - minX) * plotW);
                            g.setColor(Color.BLACK);
                            String label = v % 1 == 0 ? String.valueOf((int)v) : String.format("%.2f", v);
                            g.drawString(label, x - fm.stringWidth(label)/2, marginTop + plotH + 20);
                            g.drawLine(x, marginTop + plotH, x, marginTop + plotH + 5);
                        }

                        // Y-axis ticks
                        Set<Double> yVals = new TreeSet<>(ys);
                        for (double v : yVals) {
                            int y = marginTop + (int)((maxY - v)/(maxY - minY) * plotH);
                            g.setColor(Color.BLACK);
                            String label = v % 1 == 0 ? String.valueOf((int)v) : String.format("%.2f", v);
                            g.drawString(label, marginLeft - 10 - fm.stringWidth(label), y + fm.getAscent()/2);
                            g.drawLine(marginLeft - 5, y, marginLeft, y);
                        }

                        // Draw points
                        List<Point> points = new ArrayList<>();
                        for (int j = 0; j < xs.size(); j++) {
                            double vx = xs.get(j), vy = ys.get(j);
                            int px = marginLeft + (int)((vx - minX)/(maxX - minX) * plotW);
                            int py = marginTop + (int)((maxY - vy)/(maxY - minY) * plotH);
                            points.add(new Point(px, py));
                        }

                        g.setColor(pointColor);
                        for (Point p : points) g.fillOval(p.x - 4, p.y - 4, 8, 8);

                        // Draw line if requested
                        if (drawLine && points.size() >= 2){
                            double[] lr = linearRegression(xs, ys);
                            double a = lr[0], b = lr[1];
                            int x1 = marginLeft, x2 = marginLeft + plotW;
                            double vx1 = minX, vx2 = maxX;
                            double vy1 = a*vx1 + b, vy2 = a*vx2 + b;
                            int py1 = marginTop + (int)((maxY - vy1)/(maxY - minY) * plotH);
                            int py2 = marginTop + (int)((maxY - vy2)/(maxY - minY) * plotH);
                            g.setColor(lineColor);
                            g.setStroke(new BasicStroke(2.5f));
                            g.drawLine(x1, py1, x2, py2);
                            g.setColor(Color.BLACK);
                            g.setStroke(new BasicStroke(1f));
                            g.drawString(String.format("slope=%.4f intercept=%.4f", a, b), marginLeft + 10, marginTop + plotH + 35);
                        }

                        // Axis labels
                        g.setFont(new Font("SansSerif", Font.BOLD, 14));
                        g.drawString(xLabel, marginLeft + plotW/2 - g.getFontMetrics().stringWidth(xLabel)/2, marginTop + plotH + 45);
                        AffineTransform at = g.getTransform();
                        g.rotate(-Math.PI/2);
                        g.drawString(yLabel, -marginTop - plotH/2 - g.getFontMetrics().stringWidth(yLabel)/2, marginLeft - 50);
                        g.setTransform(at);

                        // Mean info
                        if (showMean){
                            double meanX = xs.stream().mapToDouble(d -> d).average().orElse(Double.NaN);
                            double meanY = ys.stream().mapToDouble(d -> d).average().orElse(Double.NaN);
                            g.setColor(Color.DARK_GRAY);
                            g.setFont(new Font("SansSerif", Font.PLAIN, 12));
                            String info = String.format("Count: %d    Mean %s: %s    Mean %s: %s", xs.size(),
                                    xLabel, formatNumber(meanX), yLabel, formatNumber(meanY));
                            g.drawString(info, marginLeft + 10, marginTop + plotH + 65);
                        }
                    }
                };

                chart.setPreferredSize(new Dimension(width, height));
                frame.add(chart, BorderLayout.CENTER);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            });
        }

        // --- Bar plot ---
        private void renderBar() {
            SwingUtilities.invokeLater(() -> {
                JFrame frame = new JFrame(title.isEmpty() ? yLabel + " vs " + xLabel : title);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(width, height);

                JPanel chart = new JPanel() {
                    protected void paintComponent(Graphics g0){
                        super.paintComponent(g0);
                        Graphics2D g = (Graphics2D) g0;
                        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                        int marginLeft = 80, marginRight = 40, marginTop = 50, marginBottom = 90;
                        int w = getWidth(), h = getHeight();
                        int plotW = w - marginLeft - marginRight;
                        int plotH = h - marginTop - marginBottom;

                        g.setColor(Color.WHITE);
                        g.fillRect(0, 0, w, h);

                        double minY = 0;
                        double maxY = ys.stream().mapToDouble(d -> d).max().orElse(1);
                        int n = xs.size();
                        int barW = plotW / n;

                        for (int i = 0; i < n; i++) {
                            int x = marginLeft + i * barW;
                            int barH = (int) Math.round((ys.get(i) - minY)/(maxY - minY) * plotH);
                            g.setColor(pointColor);
                            g.fillRect(x, marginTop + plotH - barH, barW - 2, barH);
                            g.setColor(Color.BLACK);
                            g.drawRect(x, marginTop + plotH - barH, barW - 2, barH);

                            // Draw value on top
                            String valStr = formatNumber(ys.get(i));
                            g.drawString(valStr, x + barW/2 - g.getFontMetrics().stringWidth(valStr)/2, marginTop + plotH - barH - 5);
                        }

                        // Axis labels
                        g.setFont(new Font("SansSerif", Font.BOLD, 14));
                        g.drawString(xLabel, marginLeft + plotW/2 - g.getFontMetrics().stringWidth(xLabel)/2, marginTop + plotH + 45);
                        AffineTransform at = g.getTransform();
                        g.rotate(-Math.PI/2);
                        g.drawString(yLabel, -marginTop - plotH/2 - g.getFontMetrics().stringWidth(yLabel)/2, marginLeft - 50);
                        g.setTransform(at);
                    }
                };

                chart.setPreferredSize(new Dimension(width, height));
                frame.add(chart, BorderLayout.CENTER);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            });
        }

        // --- Histogram ---
        private void renderHist() {
            SwingUtilities.invokeLater(() -> {
                JFrame frame = new JFrame(title.isEmpty() ? yLabel + " histogram" : title);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(width, height);

                JPanel chart = new JPanel() {
                    protected void paintComponent(Graphics g0){
                        super.paintComponent(g0);
                        Graphics2D g = (Graphics2D) g0;
                        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                        int marginLeft = 80, marginRight = 40, marginTop = 50, marginBottom = 90;
                        int w = getWidth(), h = getHeight();
                        int plotW = w - marginLeft - marginRight;
                        int plotH = h - marginTop - marginBottom;

                        g.setColor(Color.WHITE);
                        g.fillRect(0,0,w,h);

                        int bins = 10;
                        double min = xs.stream().mapToDouble(d->d).min().orElse(0);
                        double max = xs.stream().mapToDouble(d->d).max().orElse(1);
                        int[] counts = new int[bins];
                        double binSize = (max-min)/bins;
                        for(double v: xs){
                            int b = (int)((v - min)/binSize);
                            if (b >= bins) b = bins - 1;
                            counts[b]++;
                        }
                        int maxCount = Arrays.stream(counts).max().orElse(1);

                        for(int i=0;i<bins;i++){
                            int barH = (int)((counts[i]/(double)maxCount)*plotH);
                            int x = marginLeft + i*(plotW/bins);
                            g.setColor(pointColor);
                            g.fillRect(x, marginTop + plotH - barH, plotW/bins - 2, barH);
                            g.setColor(Color.BLACK);
                            g.drawRect(x, marginTop + plotH - barH, plotW/bins - 2, barH);

                            // Draw count above bar
                            String valStr = String.valueOf(counts[i]);
                            g.drawString(valStr, x + plotW/bins/2 - g.getFontMetrics().stringWidth(valStr)/2, marginTop + plotH - barH - 5);
                        }

                        // Axis labels
                        g.setFont(new Font("SansSerif", Font.BOLD, 14));
                        g.drawString(xLabel, marginLeft + plotW/2 - g.getFontMetrics().stringWidth(xLabel)/2, marginTop + plotH + 45);
                        AffineTransform at=g.getTransform();
                        g.rotate(-Math.PI/2);
                        g.drawString(yLabel, -marginTop - plotH/2 - g.getFontMetrics().stringWidth(yLabel)/2, marginLeft - 50);
                        g.setTransform(at);
                    }
                };

                chart.setPreferredSize(new Dimension(width, height));
                frame.add(chart, BorderLayout.CENTER);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            });
        }

        // --- Pie chart with labels & percentages ---
        private void renderPie() {
            SwingUtilities.invokeLater(() -> {
                JFrame frame = new JFrame(title.isEmpty() ? yLabel + " pie chart" : title);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(width, height);

                JPanel chart = new JPanel() {
                    protected void paintComponent(Graphics g0) {
                        super.paintComponent(g0);
                        Graphics2D g = (Graphics2D) g0;
                        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                        int w = getWidth(), h = getHeight();
                        double sum = xs.stream().mapToDouble(d -> d).sum();
                        double start = 0;

                        g.setFont(new Font("SansSerif", Font.PLAIN, 12));

                        for (int i = 0; i < xs.size(); i++) {
                            double value = xs.get(i);
                            double angle = value / sum * 360.0;
                            Color c = Color.getHSBColor(i / (float) xs.size(), 0.7f, 0.9f);
                            g.setColor(c);
                            g.fillArc(50, 50, w - 100, h - 100, (int)Math.round(start), (int)Math.round(angle));

                            // Draw label with percentage
                            double theta = Math.toRadians(start + angle / 2);
                            int cx = w / 2 + (int)((w / 2 - 80) * Math.cos(theta));
                            int cy = h / 2 - (int)((h / 2 - 80) * Math.sin(theta));
                            String label = String.format("%s: %.1f%%", (yIdx < column.size() ? column.get(yIdx) : "Slice"), value / sum * 100);
                            g.setColor(Color.BLACK);
                            g.drawString(label, cx - g.getFontMetrics().stringWidth(label)/2, cy);
                            start += angle;
                        }
                    }
                };

                chart.setPreferredSize(new Dimension(width, height));
                frame.add(chart, BorderLayout.CENTER);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            });
        }

        // --- Utilities ---
        private String formatNumber(double v){
            if(Double.isNaN(v)) return "NaN";
            if(Math.abs(v)>=1000 || Math.abs(v)<0.01) return String.format("%.2e",v);
            if(Math.abs(v-Math.round(v))<1e-9) return String.format("%.0f",v);
            return String.format("%.2f",v);
        }

        private double[] linearRegression(List<Double> x,List<Double> y){
            int n=Math.min(x.size(),y.size());
            double sx=0,sy=0,sxx=0,sxy=0;
            for(int i=0;i<n;i++){
                double xi=x.get(i),yi=y.get(i);
                sx+=xi; sy+=yi; sxx+=xi*xi; sxy+=xi*yi;
            }
            double denom=n*sxx-sx*sx;
            if(Math.abs(denom)<1e-12) return new double[]{0,sy/Math.max(1,n)};
            double a=(n*sxy-sx*sy)/denom;
            double b=(sy-a*sx)/n;
            return new double[]{a,b};
        }
    }

    public class Predictors {
        private JAnalytics df;
        public Predictors(JAnalytics df) { this.df = df; }

        public class LinearRegressionModel {
            private double[] coefficients;
            private boolean trained = false;

            public void train(String targetColumn, String... featureColumns) {
                List<Double> y = df.getColumnAsDouble(targetColumn);
                double[][] X = new double[y.size()][featureColumns.length+1];
                for (int i=0;i<y.size();i++) {
                    X[i][0]=1;
                    for(int j=0;j<featureColumns.length;j++) X[i][j+1]=df.getColumnAsDouble(featureColumns[j]).get(i);
                }
                coefficients=linearRegressionSolve(X,y);
                trained=true;
            }

            public double predict(double... features) {
                if(!trained) throw new IllegalStateException();
                double result=coefficients[0];
                for(int i=0;i<features.length;i++) result+=coefficients[i+1]*features[i];
                return result;
            }

            private double[] linearRegressionSolve(double[][] X, List<Double> y) {
                int m=X.length,n=X[0].length;
                double[][] XtX=new double[n][n];
                double[] Xty=new double[n];
                for(int i=0;i<m;i++){
                    for(int j=0;j<n;j++){
                        Xty[j]+=X[i][j]*y.get(i);
                        for(int k=0;k<n;k++) XtX[j][k]+=X[i][j]*X[i][k];
                    }
                }
                return solveLinearSystem(XtX,Xty);
            }

            private double[] solveLinearSystem(double[][] A,double[] b){
                int n=b.length;
                double[] x=new double[n];
                for(int i=0;i<n;i++){
                    int max=i;
                    for(int j=i+1;j<n;j++) if(Math.abs(A[j][i])>Math.abs(A[max][i])) max=j;
                    double[] tmp=A[i]; A[i]=A[max]; A[max]=tmp;
                    double t=b[i]; b[i]=b[max]; b[max]=t;
                    for(int j=i+1;j<n;j++){
                        double f=A[j][i]/A[i][i];
                        for(int k=i;k<n;k++) A[j][k]-=f*A[i][k];
                        b[j]-=f*b[i];
                    }
                }
                for(int i=n-1;i>=0;i--){
                    double sum=b[i];
                    for(int j=i+1;j<n;j++) sum-=A[i][j]*x[j];
                    x[i]=sum/A[i][i];
                }
                return x;
            }
        }

        public class SVMModel {
            private double[] weights;
            private double bias;
            private boolean trained=false;
            private double lr=0.01;
            private int epochs=1000;

            public void train(String targetColumn, String featureColumn){
                List<Double> y=df.getColumnAsDouble(targetColumn);
                List<Double> X=df.getColumnAsDouble(featureColumn);
                weights=new double[1];
                bias=0;
                for(int e=0;e<epochs;e++){
                    for(int i=0;i<y.size();i++){
                        double yi=y.get(i)>0?1:-1;
                        double xi=X.get(i);
                        double condition=yi*(weights[0]*xi+bias);
                        if(condition<1){weights[0]+=lr*yi*xi; bias+=lr*yi;}
                    }
                }
                trained=true;
            }

            public double predict(double x){
                if(!trained) throw new IllegalStateException();
                return weights[0]*x+bias;
            }
        }

        public class SimpleNN {
            private double weight,bias;
            private boolean trained=false;

            public void train(String targetColumn,String featureColumn){
                List<Double> y=df.getColumnAsDouble(targetColumn);
                List<Double> X=df.getColumnAsDouble(featureColumn);
                weight=0; bias=0; double lr=0.001;
                for(int epoch=0;epoch<500;epoch++){
                    for(int i=0;i<X.size();i++){
                        double pred=weight*X.get(i)+bias;
                        double error=y.get(i)-pred;
                        weight+=lr*error*X.get(i);
                        bias+=lr*error;
                    }
                }
                trained=true;
            }

            public double predict(double x){
                if(!trained) throw new IllegalStateException();
                return weight*x+bias;
            }
        }

        public class DecisionTree {
            private Node root;
            private boolean trained=false;

            private class Node {
                int feature; double value;
                Node left,right; double prediction;
            }

            public void train(String targetColumn,String featureColumn){
                List<Double> y=df.getColumnAsDouble(targetColumn);
                List<Double> X=df.getColumnAsDouble(featureColumn);
                root=buildTree(X,y);
                trained=true;
            }

            private Node buildTree(List<Double> X,List<Double> y){
                Node n=new Node();
                if(X.size()<=2){ n.prediction=y.stream().mapToDouble(d->d).average().orElse(0); return n;}
                int bestSplit=0; double bestValue=0, bestScore=Double.MAX_VALUE;
                for(int i=0;i<X.size();i++){
                    double split=X.get(i);
                    List<Double> leftY=new ArrayList<>(), rightY=new ArrayList<>();
                    for(int j=0;j<X.size();j++){
                        if(X.get(j)<=split) leftY.add(y.get(j)); else rightY.add(y.get(j));
                    }
                    if(leftY.isEmpty()||rightY.isEmpty()) continue;
                    double score=variance(leftY)*leftY.size()+variance(rightY)*rightY.size();
                    if(score<bestScore){bestScore=score; bestSplit=i; bestValue=split;}
                }
                n.feature=0; n.value=bestValue;
                List<Double> leftX=new ArrayList<>(), rightX=new ArrayList<>();
                List<Double> leftY=new ArrayList<>(), rightY=new ArrayList<>();
                for(int i=0;i<X.size();i++){
                    if(X.get(i)<=bestValue){leftX.add(X.get(i)); leftY.add(y.get(i));}
                    else{rightX.add(X.get(i)); rightY.add(y.get(i));}
                }
                if(!leftX.isEmpty()) n.left=buildTree(leftX,leftY);
                if(!rightX.isEmpty()) n.right=buildTree(rightX,rightY);
                n.prediction=y.stream().mapToDouble(d->d).average().orElse(0);
                return n;
            }

            private double variance(List<Double> vals){
                double mean=vals.stream().mapToDouble(d->d).average().orElse(0);
                return vals.stream().mapToDouble(d->d-mean).map(v->v*v).average().orElse(0);
            }

            public double predict(double x){
                if(!trained) throw new IllegalStateException();
                Node n=root;
                while(n.left!=null || n.right!=null){
                    if(x<=n.value) n=n.left; else n=n.right;
                }
                return n.prediction;
            }
        }

        public class KNN {
            private int k=3;
            private List<Double> Xdata, Ydata;
            private boolean trained=false;
            public void setK(int k){ this.k=k; }
            public void train(String targetColumn,String featureColumn){
                Xdata=df.getColumnAsDouble(featureColumn);
                Ydata=df.getColumnAsDouble(targetColumn);
                trained=true;
            }
            public double predict(double x){
                if(!trained) throw new IllegalStateException();
                List<double[]> dist=new ArrayList<>();
                for(int i=0;i<Xdata.size();i++) dist.add(new double[]{Math.abs(Xdata.get(i)-x),Ydata.get(i)});
                dist.sort(Comparator.comparingDouble(a->a[0]));
                return dist.subList(0,k).stream().mapToDouble(a->a[1]).average().orElse(0);
            }
        }

        public class NaiveBayes {
            private Map<Double,Integer> counts=new HashMap<>();
            private int total=0;
            private boolean trained=false;
            public void train(String targetColumn){
                List<Double> y=df.getColumnAsDouble(targetColumn);
                for(double v:y){ counts.put(v,counts.getOrDefault(v,0)+1); total++; }
                trained=true;
            }
            public double predict(double v){
                if(!trained) throw new IllegalStateException();
                return counts.getOrDefault(v,0)/(double)total;
            }
        }
    }

    public List<Double> getColumnAsDouble(String col){
        int idx=column.indexOf(col);
        if(idx==-1) throw new IllegalArgumentException();
        List<Double> out=new ArrayList<>();
        for(List<String> r:row){
            try{ out.add(Double.parseDouble(r.get(idx))); } catch(Exception e){ }
        }
        return out;
    }


}
