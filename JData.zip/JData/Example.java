package JData;

import java.util.*;

public class Example {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        JAnalytics df = new JAnalytics();
        df.readCSV("data.csv");
        df.head();
        df.mean("Year");

        JAnalytics.GenerativeModel gpt = df.new GenerativeModel();

        // === Ultra Fine-Tuning for High Accuracy ===
        gpt.epoch(120)                              // very long training — ensures full convergence across entire dataset
                .tuning(0.85)                        // slow, conservative updates — minimizes gradient noise and prevents overfitting
                .topK(50)                            // massive candidate pool — allows broad contextual blending and answer synthesis
                .similarityThreshold(0.12)           // relaxed similarity limit — captures semantically related but phrased-differently questions
                .idfWeight(3.6)                      // extremely strong rare-term emphasis — highlights unique identifiers (e.g., “creator”, “JAnalytics”)
                .semanticWeight(3.2)                 // maximizes semantic embedding weight — meaning-first retrieval over token overlap
                .standardDeviationWeight(0.7)        // smooths frequency bias — keeps frequent neutral terms from dominating
                .meanAdjustment(true)                // ensures normalized embeddings — stable cosine similarity comparisons across passes
                .enableAdvancedCleaning(true)        // full linguistic cleaning — removes noise, filler words, and redundant text patterns
                .responseStyle(JAnalytics.GenerativeModel.ResponseStyle.BALANCED); // maintains accuracy + explanatory depth

        System.out.println("Training the model with deeply tuned hyperparameters...");
        gpt.trainFromFile("JData/training.txt");
        System.out.println("Training completed successfully with enhanced semantic precision.\n");

        while (true) {
            System.out.print("Ask a question (or type 'exit'): ");
            String prompt = sc.nextLine();
            if (prompt.equalsIgnoreCase("exit")) break;

            gpt.prompt(prompt);
            String response = gpt.answer();
            System.out.println("→ " + response);
            System.out.println();
        }

        sc.close();
    }
}
