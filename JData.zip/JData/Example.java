package JData;

import java.util.*;

public class Example {
    public static void main(String[] args) {
        JAnalytics df = new JAnalytics();
        Scanner sc = new Scanner(System.in);
        df.readCSV("data.csv");
        df.head();
        df.mean("Year");
        System.out.println(df);

        JAnalytics.GenerativeModel gpt = df.new GenerativeModel();

        gpt.trainFromFile("JData/training.txt");

        String c = sc.nextLine();
        gpt.prompt(c);
        System.out.println(gpt.answer());

        String cs = sc.nextLine();
        gpt.prompt(cs);
        System.out.println(gpt.answer());

        String vm = sc.nextLine();
        gpt.prompt(vm);
        System.out.println(gpt.answer());
    }
}